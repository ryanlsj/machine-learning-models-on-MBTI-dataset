import pandas as pd
import numpy as np
from sklearn.linear_model import Perceptron
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import SGDClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import mean_squared_error
from sklearn.svm import LinearSVC
from sqlalchemy import true
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer
import seaborn as sn  
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
from sklearn.metrics import recall_score as rs
from sklearn.metrics import precision_score as ps
from sklearn.metrics import accuracy_score as accu
from sklearn.preprocessing import LabelEncoder

# data=np.load('test\data.npy',allow_pickle=True).item()
# data_df = pd.DataFrame(data)
# data_df.to_csv('test\data.csv')
# finaldata=pd.read_csv('test\data.csv')

finaldata = pd.read_csv('test\mbti_1.csv',encoding= 'unicode_escape')
x=finaldata['posts']
y=finaldata['type']


X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2,)


tfidf = TfidfVectorizer(stop_words='english')
X_train = tfidf.fit_transform(X_train).todense()
X_test = tfidf.transform(X_test).todense()
le = LabelEncoder()
y_train=le.fit_transform(y_train)
y_test=le.fit_transform(y_test)
# print(X_test.shape)
# print(y_test.shape)



model1 = LogisticRegression()
model1.fit(X_train, y_train)
y_pred=model1.predict(X_test)

print('accuracy:',accu(y_test, y_pred))
print('precision:',ps(y_test, y_pred, average="macro"))
print('recall score:',rs(y_test, y_pred, average="macro"))
cm = confusion_matrix(y_test, y_pred)
sn.heatmap(cm, annot=True, cmap="Blues", fmt='g')
plt.show()


lr = SGDClassifier(loss='hinge',alpha=0.001,class_weight='balanced')
clf =lr.fit(X_train, y_train)
calibrator = CalibratedClassifierCV(clf, cv='prefit')
# model=calibrator.fit(X_train, y_train)
# y_pred=model.predict(X_test)
# cm = confusion_matrix(y_test, y_pred)
# sn.heatmap(cm, annot=True, cmap="Blues", fmt='g')
# plt.show()
# print('accuracy:',accu(y_test, y_pred))
# print('precision:',ps(y_test, y_pred, average="macro"))
# print('recall score:',rs(y_test, y_pred, average="macro"))

model3 = GaussianNB()
# model3.fit(X_train, y_train)
# y_pred=model3.predict(X_test)
# cm = confusion_matrix(y_test, y_pred)
# sn.heatmap(cm, annot=True, cmap="Blues", fmt='g')
# plt.show()
# print('accuracy:',accu(y_test, y_pred))
# print('precision:',ps(y_test, y_pred, average="macro"))
# print('recall score:',rs(y_test, y_pred, average="macro"))
def plot_learning_curves(model, X, y):
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2)
    train_errors, val_errors =[],[]
    for m in range(1, len(X_train)):
        model.fit(X_train[:m], y_train[:m])
        y_train_predict = model.predict(X_train[:m])
        y_val_predict = model.predict(X_val)
        train_errors.append(mean_squared_error(y_train_predict, y_train[:m]))
        val_errors.append(mean_squared_error(y_val_predict, y_val))
        plt.plot(np.sqrt(train_errors),"r-+", linewidth=2, label="train")
        plt.plot(np.sqrt(val_errors),"b-", linewidth=3, label="val")

plot_learning_curves(model3,X_train,y_train)